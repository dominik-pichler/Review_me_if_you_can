from utils.Extraction_Manager import Extraction_Manager
from datetime import datetime, timedelta
from utils.Handler_ABTs import Handler_ABTs

def lambda_handler(event, context):
    try:
        print("log_test!")
        today = datetime.now()
        since_delta = today - timedelta(days=2)
        since_delta = since_delta.strftime('%Y-%m-%d %H:%M:%S')

        extraction_manager = Extraction_Manager()
        e = extraction_manager.run_fetch_data_handler(delta=True, since_delta=since_delta)
        abt_manager = Handler_ABTs()
        e = abt_manager.load_ABTs()

        return {
            'statusCode': 200,
            'body': 'Data fetch and stored complete',
            'e':str(e)
        }
    except Exception as e:
        print(f"Fehler + {e}")
        return {
            'statusCode': 500,
            'body': str(e)
        }
