import psycopg2
import sys
import os

# Add the parent directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Now you can import the credentials module
import credentials

def _execute_sql_file(conn, cursor, sql_file_paths):
    try:
        for sql_file_path in sql_file_paths:
            # Read the SQL file
            with open(sql_file_path, 'r') as file:
                sql_script = file.read()

            # Split the script into individual statements
            sql_statements = sql_script.split(';')

            # Execute each statement
            for statement in sql_statements:
                print(f'Executing statement {statement}')
                # Strip whitespace and check if the statement is not empty
                if statement.strip():
                    try:
                        cursor.execute(statement)
                    except Exception as e:
                        print(f"An error occurred while executing {sql_file_path}: {e}")
                        conn.rollback()  # Rollback the transaction on error
                        break
            else:
                # Commit if all statements in the script executed successfully
                conn.commit()
                print(f"SQL script {sql_file_path} executed successfully.")
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        # Close the cursor and connection
        cursor.close()
        conn.close()


class Handler_ABTs:
    def __init__(self):
        try:
            conn = psycopg2.connect(
                host=credentials.AH_HOSTNAME,
                user=credentials.AH_USERNAME,
                password=credentials.AH_PASSWORD,
                dbname=credentials.AH_DB_NAME,
                port=credentials.AH_PORT
            )
            cursor = conn.cursor()
        except psycopg2.Error as e:
            print(f"ERROR: Could not connect to PostgreSQL instance. {e}")
            raise e
        self.conn = conn
        self.cursor = cursor
        self.cursor = self.conn.cursor()
        self.list_ABTs = ['utils/components/BAS/ABT_CLEANING_PER_APP.sql',
                          'utils/components/BAS/ABT_NFC.sql',
                          'utils/components/BAS/ABT_NFC_PER_CLEANER.sql',
                          'utils/components/BAS/ABT_CLEANING_TIME_ANALYSIS.sql',
                          'utils/components/BAS/ABT_CLEANING_TIME_GROUPING.sql'
                          ]

    def load_ABTs(self):
        print("Lets go ABTs")
        _execute_sql_file(self.conn,self.cursor, self.list_ABTs)


if __name__ == '__main__':
    manager = Handler_ABTs()
    manager.load_ABTs()