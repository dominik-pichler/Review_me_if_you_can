import requests
from credentials import KROSS_BASE_URL,KROSS_API_KEY,KROSS_HOTEL_ID,KROSS_USERNAME,KROSS_PASSWORD
import json
import time
from datetime import datetime

def _get_access_token() -> str:
    endpoint = f'{KROSS_BASE_URL}/v5/auth/get-token'
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = {
        'grant_type': 'password',
        "api_key": KROSS_API_KEY,
        "hotel_id": KROSS_HOTEL_ID,
        "username": KROSS_USERNAME,
        "password": KROSS_PASSWORD
    }

    response = requests.post(endpoint, headers=headers, data=data)

    if response.status_code == 200:
        return response.json()
    else:
        return {
            'error': f'Failed to retrieve access token: {response.status_code}',
            'message': response.text
        }


class Handler_Kross_API:
    def __init__(self,start_time):
        token_json = _get_access_token()
        self.access_token = token_json['auth_token']
        self.start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d')
        self.end_time = datetime.now().strftime('%YYYY-%mm-%dd')

    def get_tracked_reviews(self) -> json:

            url = "https://api.krossbooking.com/v5/reviews/get-list"
            headers = {
                "Authorization": f"Bearer {self.access_token}"
            }

            data = {
                "date_from": self.start_time,
                "date_to": self.end_time,
                "offset": 0,
            }

            all_entries = []

            while True:
                response = requests.get(url, headers=headers, json=data)
                response_data = response.json()
                time.sleep(0.1)


                try:
                    if response_data['count'] > 0:
                        entries = response_data['data']
                        all_entries.extend(entries)

                        # If we received fewer entries than the limit, we are done
                        if len(entries) < 200:
                           break

                        # Otherwise, increment the offset for the next request
                        data['offset'] += 200
                    else:
                        print("No 'Results' key in response data or no more data to fetch.")
                        break
                except Exception as e:
                    print(f"weird exception: {e} {response_data}")
                    pass
            # Final output
            print(f"Total entries collected: {len(all_entries)}")


            return all_entries