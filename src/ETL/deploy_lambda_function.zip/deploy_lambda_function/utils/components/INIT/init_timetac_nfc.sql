DROP TABLE IF EXISTS extr_timetac_nfc_tracks;

CREATE TABLE IF NOT EXISTS extr_timetac_nfc_tracks (
    id INTEGER PRIMARY KEY,
    mode_id INTEGER,
    unique_id TEXT,
    user_id INTEGER,
    task_id INTEGER,
    start_task_afterwards INTEGER,
    project_id INTEGER,
    checkpoint_id INTEGER,
    skill_id INTEGER,
    client_unique_id TEXT,
    created TEXT,
    data_changed TEXT
);