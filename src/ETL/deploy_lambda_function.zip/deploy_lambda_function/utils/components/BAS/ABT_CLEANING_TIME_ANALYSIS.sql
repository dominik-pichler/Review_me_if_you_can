DROP TABLE IF EXISTS ABT_CLEANING_TIME_ANALYSIS;
CREATE TABLE ABT_CLEANING_TIME_ANALYSIS AS
SELECT
    fullname,
    DATE(start_time) AS date,
    MIN(start_time::time) AS first_start,
    MAX(start_time::time) AS last_start,
    MAX(end_time::time) AS last_end_time
FROM
    extr_timetac_time_entries t
LEFT JOIN
    extr_timetac_users u ON t.user_id = u.id
GROUP BY
    fullname,
    DATE(start_time)
ORDER BY
    fullname,
    date;