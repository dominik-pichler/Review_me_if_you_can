DROP TABLE IF EXISTS ABT_CLEANING_PER_APP;

CREATE TABLE IF NOT EXISTS ABT_CLEANING_PER_APP AS
WITH BAS_FULL_TIMETAC AS (
SELECT extr_timetac_tasks.name                                            AS APPARTMENT,
       extr_timetac_users.fullname                                        AS REINIGUNGSMITARBEITER,
       te.start_time::timestamp                                           AS REININGUNGSSTARTDATUM,
       te.end_time::timestamp                                             AS REININGUNGSENDDATUM,
       ROUND(EXTRACT(EPOCH FROM (te.end_time - te.start_time)) / 3600, 2) AS REINIGUNGSDAUER
FROM extr_timetac_time_entries te
         LEFT JOIN extr_timetac_users
                   ON te.user_id = extr_timetac_users.id
         LEFT JOIN extr_timetac_tasks
                   ON te.task_id = extr_timetac_tasks.id ORDER BY start_time DESC),
BAS_REVIEW_MAPPER AS (
SELECT map.Aufgabe_TimeTac, me.* -- Inner join der Reviews!!
                      FROM extr_kross_reviews me
                      LEFT JOIN MAPPING_KROSS_TIMETAC map
                             ON me.name_room_type = map.Aufgabe_Kross
)
SELECT *
FROM BAS_FULL_TIMETAC timetac
         LEFT JOIN BAS_REVIEW_MAPPER kross
                   ON timetac.APPARTMENT = kross.Aufgabe_TimeTac
                   AND (kross.date - timetac.REININGUNGSSTARTDATUM) < INTERVAL '2 day'
                   AND (kross.date - timetac.REININGUNGSSTARTDATUM) >= INTERVAL '0 day'
        LEFT JOIN TARGET_TIME_CLEANING_PER_APT t ON timetac.APPARTMENT = t.TASK_TIMETAC;