DROP TABLE IF EXISTS ABT_NFC_KPI_CLEANER;

CREATE TABLE IF NOT EXISTS ABT_NFC_KPI_CLEANER AS
SELECT fullname,
       TASK_DATUM,
       SUM(CASE WHEN NFC_Flag = 0 THEN 1 ELSE 0 END) AS NFC_Flag_0_Count,
       SUM(CASE WHEN NFC_Flag = 1 THEN 1 ELSE 0 END) AS NFC_Flag_1_Count,
       ROUND(SUM(CASE WHEN NFC_Flag = 0 THEN 1 ELSE 0 END) * 1.0 / COUNT(*) * 100, 2) AS NFC_Flag_0_Share,
       ROUND(SUM(CASE WHEN NFC_Flag = 1 THEN 1 ELSE 0 END) * 1.0 / COUNT(*) * 100, 2) AS NFC_Flag_1_Share
FROM (
    SELECT extr_timetac_users.fullname,
           DATE(t.start_time) AS TASK_DATUM,
           t.task_id,
           CASE WHEN nt.ID IS NOT NULL THEN 1 ELSE 0 END AS NFC_Flag
    FROM extr_timetac_time_entries t
             LEFT JOIN extr_timetac_users ON t.user_id = extr_timetac_users.id
             LEFT JOIN extr_timetac_nfc_tracks nt ON nt.task_id = t.task_id
) subquery
GROUP BY fullname, TASK_DATUM
ORDER BY fullname ASC, TASK_DATUM ASC;
