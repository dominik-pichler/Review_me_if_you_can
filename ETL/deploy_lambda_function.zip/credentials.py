
### Timetac
TIMETAC_CLIENT_ID = 'CLIENT__API_USER_8F952'
TIMETAC_CLIENT_SECRET = 'c03e4f1ef3634ce71b487d875d93dd981e37713e6a9ecc0d2123a76893e8af16e9f1aa389bc8ec41'

TIMETAC_BASE_URL_PROD = 'https://api.timetac.com/ahinvestorsgroup'


TIMETAC_CLIENT_ID_PROD = 'CLIENT__API_USER_78E87'
TIMETAC_API_KEY_PROD = 'd34d67ab32926bb83fe0336e6edfde639e357611e13ea512720260e72af3da797918121ae0ab5c01'

TIMETAC_USERNAME = 'lpirker'
TIMETAC_PASSWORD = 'Ln3qAyPd6Qv!JpeK'


### kross
KROSS_API_KEY = '37d189a699bd4cf606854d1559ad7604'
KROSS_HOTEL_ID = 'mwapartmentgmbh'
KROSS_USERNAME = 'admin'
KROSS_PASSWORD = 'Admin123ah'
KROSS_BASE_URL = 'https://api.krossbooking.com/'


### DWH:
AH_DB_NAME = 'ah_group'
AH_HOSTNAME = 'testingdb1.cta6ay0ku4z9.eu-north-1.rds.amazonaws.com'
AH_PASSWORD = 'TsCB2T3q5g6WiDtMz34'
AH_PORT = 5432
AH_SCHEMA_NAME = 'ah_group_bas'
AH_USERNAME = 'postgres'


''''### Timetac
TIMETAC_CLIENT_ID = 'CLIENT__API_USER_8F952'
TIMETAC_CLIENT_SECRET = 'c03e4f1ef3634ce71b487d875d93dd981e37713e6a9ecc0d2123a76893e8af16e9f1aa389bc8ec41'
TIMETAC_USERNAME = 'lpirker'
TIMETAC_PASSWORD = 'Ln3qAyPd6Qv!JpeK'
TIMETAC_BASE_URL = 'https://api-sandbox.timetac.com/ahinvestorsgroup1'

### kross
KROSS_API_KEY = '37d189a699bd4cf606854d1559ad7604'
KROSS_HOTEL_ID = 'mwapartmentgmbh'
KROSS_USERNAME = 'admin'
KROSS_PASSWORD = 'Kross123mw'
KROSS_BASE_URL = 'https://api.krossbooking.com/'


### DWH:
AH_DB_NAME = 'ah_group'
AH_HOSTNAME = 'testingdb1.cta6ay0ku4z9.eu-north-1.rds.amazonaws.com'
AH_PASSWORD = 'TsCB2T3q5g6WiDtMz34'
AH_PORT = 5432
AH_SCHEMA_NAME = 'ah_group_bas'
AH_USERNAME = 'postgres'
'''