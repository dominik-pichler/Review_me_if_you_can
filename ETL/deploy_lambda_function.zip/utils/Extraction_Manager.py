import os
from utils.Handler_TimeTac_API import Handler_TimeTac_API
from utils.Handler_Kross_API import Handler_Kross_API
from credentials import AH_DB_NAME,AH_HOSTNAME,AH_PASSWORD,AH_PORT,AH_SCHEMA_NAME,AH_USERNAME
import psycopg2
class Extraction_Manager:
    def __init__(self,local_test = True):
        if local_test == False:
            # Retrieve database connection parameters from environment variables
            rds_host = os.environ['RDS_HOST']
            db_username = os.environ['DB_USERNAME']
            db_password = os.environ['DB_PASSWORD']
            db_name = os.environ['DB_NAME']
            db_port = os.environ.get('DB_PORT', 5432)# Default PostgreSQL port is 5432
            db_schema = os.environ.get('DB_SCHEMA', 'AH_GROUP')

        else:
            rds_host = AH_HOSTNAME
            db_username = AH_USERNAME
            db_password = AH_PASSWORD
            db_name = AH_DB_NAME
            db_port = AH_PORT
            db_schema = AH_SCHEMA_NAME

        # Establish a connection to the RDS PostgreSQL database
        try:
            self.conn = psycopg2.connect(
                host=rds_host,
                user=db_username,
                password=db_password,
                dbname=db_name,
                port=db_port
            )
            self.cursor = self.conn.cursor()
        except psycopg2.Error as e:
            print(f"ERROR: Could not connect to PostgreSQL instance. {e}")
            raise


    # TODO: Insert Datenstände
    # TODO: Die ganzen Duplicated Code Segments über Decorator o.ä  Patterns lösen - ist doch ein Zustand so!

    def insert_into_tasks_table(self, json_data: list) -> int:
        '''
        Full load of all users in the extract table
        :return: Number of users added in the current function call
        :rtype: int
        '''

        # Insert JSON data into the table
        insert_query = """
        INSERT INTO extr_timetac_tasks (
            id, mother_id, view_id, sort_order, node_path, ultimate_mother_id, name, is_done, view_order, 
            icon_name, custom_icon_name, initial_duration, target_duration, target_duration_sum_up_by_task, 
            begin, deadline, object_type, notes, client_id, t_iv_1, t_iv_2, t_iv_3, t_iv_4, t_iv_5, t_iv_6, 
            approve_by_project_leader, duration, color, has_children, translate_task_name, 
            allow_task_project_edit, allow_task_project_delete, status, external_id, is_startable, 
            is_billable, is_nonworking, is_paid_non_working, internal_cost_per_hour, revenue_per_hour, 
            skill_id, priority, is_restricted, jira_id, name_path
        ) VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, -- 20
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,         -- 18
            %s, %s, %s, %s, %s
        );
        """
        count_stored_tasks = 0
        for record in json_data:
            try:
                self.cursor.execute(insert_query, (
                    record['id'],
                    record['mother_id'],
                    record['view_id'],
                    record['sort_order'],
                    record['node_path'],
                    record['ultimate_mother_id'],
                    record['name'],
                    record['is_done'],
                    record['view_order'],
                    record['icon_name'],
                    record['custom_icon_name'],
                    record['initial_duration'],
                    record['target_duration'],
                    record['target_duration_sum_up_by_task'],
                    record['begin'] if record['begin'] != '0000-00-00' else None,  # Handle invalid dates
                    record['deadline'] if record['deadline'] != '0000-00-00' else None,  # Handle invalid dates
                    record['object_type'],
                    record['notes'],
                    record['client_id'],
                    float(record['t_iv_1']) if record['t_iv_1'] else 0.0,  # Ensure decimal type for t_iv_1
                    record['t_iv_2'],
                    record['t_iv_3'],
                    record['t_iv_4'],
                    record['t_iv_5'],
                    record['t_iv_6'],
                    record['approve_by_project_leader'],
                    record['duration'],
                    record['color'],
                    record['has_children'],
                    record['translate_task_name'],
                    record['allow_task_project_edit'],
                    record['allow_task_project_delete'],
                    record['status'],
                    record['external_id'],
                    record['is_startable'],
                    record['is_billable'],
                    record['is_nonworking'],
                    record['is_paid_non_working'],
                    record['internal_cost_per_hour'],
                    record['revenue_per_hour'],
                    record['skill_id'],
                    record['priority'],
                    record['is_restricted'],
                    record['jira_id'],
                    record['name_path']
                ))
                count_stored_tasks += 1
                self.conn.commit()
            except Exception as e:
                self.conn.rollback()
                print(f"Transaction rolled back due to error: {e}")
                continue

        return f"Stored {count_stored_tasks} / {len(json_data)} in the DWH"
    def insert_into_users_table(self, json_data: tuple) -> int:
        def clean_date(date_value):
            # Replace '0000-00-00' with None or a valid default date
            return None if date_value == '0000-00-00' else date_value

        insert_query = """
        INSERT INTO extr_timetac_users (
            id, active, hr_manager, department_id, department_id_valid_from, role_id, start_task_at_login, username, 
            personnel_number, title, lastname, firstname, fullname, abbrevation, restrict_to_ip, permission_show_tt_ex_post_one_employees, 
            permission_show_assign_favourites, permission_show_assign_todos, internal_cost_per_hour, revenue_per_hour, email_address, 
            language_id, phone, skype, profile_picture, u_iv_1, u_iv_1_valid_from, u_iv_2, u_iv_2_valid_from, u_iv_3, u_iv_3_valid_from, 
            u_iv_4, u_iv_4_valid_from, u_iv_5, u_iv_5_valid_from, u_iv_6, u_iv_6_valid_from, mobile_allowed, mobile_allow_live_timetracking, 
            country_id, allowed_ips, payroll_accounting_starts_at, payroll_accounting_initial_value_working_time_total_balance, public_holiday_template_id, 
            public_holiday_template_id_valid_from, manual_timetracking, automatic_tracker_writing_task_id, cost_acc_non_working_task_id, phone_1, phone_2, 
            birthday, entry_date, exit_date, notes, social_security_number, address_1, address_2, zip, permission_show_edit_user_user_settings, 
            terminal_transponder_nr, external_id, company_name, timesheet_template_id, timesheet_template_id_valid_starting_from, 
            timesheet_holiday_calc_yearly_amount, timesheet_holiday_calc_starting_from, timesheet_holiday_calc_interval_mode, working_time_balance_rule, 
            working_time_balance_rule_valid_from, overtime_allowance_included_overtime_hours_per_cycle, payroll_accounting_initial_value_holiday, 
            enable_module_employee_timetracking, enable_module_project_timetracking, enable_module_leave_management, enable_module_shift_planning, 
            leave_note, request_substitute_user_id, time_tracking_ex_post_earliest_working_time, exclude_from_sync, human, automatic_break_template_id, 
            automatic_break_template_valid_starting_from, unsuccessful_login_count, authentication_blocked, user_role_ids
        ) VALUES (
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
        %s, %s, %s, %s, %s);
        """
        count_users = 0
        for record in json_data:
            try:
                self.cursor.execute(insert_query, (
                    record['id'], record['active'], record['hr_manager'], record['department_id'],
                    clean_date(record['department_id_valid_from']),
                    record['role_id'], record['start_task_at_login'], record['username'], record['personnel_number'],
                    record['title'],
                    record['lastname'], record['firstname'], record['fullname'], record['abbrevation'],
                    record['restrict_to_ip'],
                    record['permission_show_tt_ex_post_one_employees'], record['permission_show_assign_favourites'],
                    record['permission_show_assign_todos'],
                    record['internal_cost_per_hour'], record['revenue_per_hour'], record['email_address'],
                    record['language_id'], record['phone'],
                    record['skype'], record['profile_picture'], record['u_iv_1'], clean_date(record['u_iv_1_valid_from']),
                    record['u_iv_2'], clean_date(record['u_iv_2_valid_from']),
                    record['u_iv_3'], clean_date(record['u_iv_3_valid_from']), record['u_iv_4'],
                    clean_date(record['u_iv_4_valid_from']),
                    record['u_iv_5'], clean_date(record['u_iv_5_valid_from']),
                    record['u_iv_6'], clean_date(record['u_iv_6_valid_from']), record['mobile_allowed'],
                    record['mobile_allow_live_timetracking'], record['country_id'],
                    record['allowed_ips'], clean_date(record['payroll_accounting_starts_at']),
                    record['payroll_accounting_initial_value_working_time_total_balance'],
                    record['public_holiday_template_id'], clean_date(record['public_holiday_template_id_valid_from']),
                    record['manual_timetracking'],
                    record['automatic_tracker_writing_task_id'], record['cost_acc_non_working_task_id'], record['phone_1'],
                    record['phone_2'], clean_date(record['birthday']),
                    clean_date(record['entry_date']), clean_date(record['exit_date']), record['notes'],
                    record['social_security_number'],
                    record['address_1'], record['address_2'],
                    record['zip'], record['permission_show_edit_user_user_settings'], record['terminal_transponder_nr'],
                    record['external_id'],
                    record['company_name'], record['timesheet_template_id'],
                    clean_date(record['timesheet_template_id_valid_starting_from']),
                    record['timesheet_holiday_calc_yearly_amount'],
                    clean_date(record['timesheet_holiday_calc_starting_from']),
                    record['timesheet_holiday_calc_interval_mode'],
                    record['working_time_balance_rule'], clean_date(record['working_time_balance_rule_valid_from']),
                    record['overtime_allowance_included_overtime_hours_per_cycle'],
                    record['payroll_accounting_initial_value_holiday'], record['enable_module_employee_timetracking'],
                    record['enable_module_project_timetracking'],
                    record['enable_module_leave_management'], record['enable_module_shift_planning'], record['leave_note'],
                    record['request_substitute_user_id'],
                    clean_date(record['time_tracking_ex_post_earliest_working_time']), record['exclude_from_sync'],
                    record['human'],
                    record['automatic_break_template_id'],
                    clean_date(record['automatic_break_template_valid_starting_from']), record['unsuccessful_login_count'],
                    record['authentication_blocked'], record['user_role_ids']
                ))
                count_users += 1
                self.conn.commit()
            except Exception as e:
                self.conn.rollback()
                print(f"Transaction rolled back due to error: {e}")
                continue

        return f"Stored {count_users} / {len(json_data)} in the DWH"

    def insert_into_time_table(self, json_data: tuple) -> int:
        def clean_datetime(datetime_value):
            # Replace invalid datetime values with None
            return None if datetime_value in ['0000-00-00', '0000-00-00 00:00:00'] else datetime_value

        insert_query = """
        INSERT INTO extr_timetac_time_entries (
            id, 
            user_id, 
            department_id,
            department_role_id,
            task_id, start_time,
            end_time, 
            start_time_offset, 
            end_time_offset, 
            start_time_timezone,
            end_time_timezone, 
            is_start_live, 
            is_end_live, 
            duration, 
            status,
            start_ip, 
            end_ip, 
            is_statistic_countable, 
            max_hours_alert,
            is_billable,
            notes,
            input_type, 
            t_iv_1,
            t_iv_2,
            t_iv_3,
            t_iv_4, 
            t_iv_5, 
            t_iv_6,
            u_iv_1,
            u_iv_2,
            u_iv_3,
            u_iv_4, 
            u_iv_5,
            u_iv_6,
            is_nonworking,
            approved_by_admin, 
            status_invoicing, 
            invoice_id,
            geo_start_lat, 
            geo_start_long,
            geo_start_accuracy,
            geo_end_lat, 
            geo_end_long,
            geo_end_accuracy, 
            created_at,
            updated, 
            last_change_time_tracking_request_id,
            client_unique_id,
            start_type_id,
            end_type_id, 
            is_paid_non_working,
            start_oauth_client_id, 
            end_oauth_client_id,
            absence_request_id,
            start_timezone, 
            end_timezone
        ) VALUES (
        %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
         %s, %s, %s, %s,%s,%s);
        """
        count_time = 0
        for record in json_data:
            try:
                self.cursor.execute(insert_query, (
                    record['id'],
                    record['user_id'],
                    record['department_id'],
                    record['department_role_id'],
                    record['task_id'],
                    clean_datetime(record['start_time']),
                    clean_datetime(record['end_time']),
                    record['start_time_offset'],
                    record['end_time_offset'],
                    record['start_time_timezone'],
                    record['end_time_timezone'],
                    record['is_start_live'],
                    record['is_end_live'],
                    record['duration'],
                    record['status'],
                    record['start_ip'],
                    record['end_ip'],
                    record['is_statistic_countable'],
                    record['max_hours_alert'],
                    record['is_billable'],
                    record['notes'],
                    record['input_type'],
                    record['t_iv_1'],
                    record['t_iv_2'],
                    record['t_iv_3'],
                    record['t_iv_4'],
                    record['t_iv_5'],
                    record['t_iv_6'],
                    record['u_iv_1'],
                    record['u_iv_2'],
                    record['u_iv_3'],
                    record['u_iv_4'],
                    record['u_iv_5'],
                    record['u_iv_6'],
                    record['is_nonworking'],
                    record['approved_by_admin'],
                    record['status_invoicing'],
                    record['invoice_id'],
                    record['geo_start_lat'],
                    record['geo_start_long'],
                    record['geo_start_accuracy'],
                    record['geo_end_lat'],
                    record['geo_end_long'],
                    record['geo_end_accuracy'],
                    clean_datetime(record['created_at']),
                    clean_datetime(record['updated']),
                    record['last_change_time_tracking_request_id'],
                    record['client_unique_id'],
                    record['start_type_id'],
                    record['end_type_id'],
                    record['is_paid_non_working'],
                    record['start_oauth_client_id'],
                    record['end_oauth_client_id'],
                    record['absence_request_id'],
                    record['start_timezone'],
                    record['end_timezone']
                ))
                count_time += 1
                self.conn.commit()

            except Exception as e:
                self.conn.rollback()
                print(f"Transaction rolled back due to error: {e}")
                continue

        return f"Stored {count_time} / {len(json_data)} in the DWH"

    def insert_into_nfc_table(self, json_data: tuple) -> int:
        count_nfc = 0
        for record in json_data:
            try:
                self.cursor.execute('''
                    INSERT INTO extr_timetac_nfc_tracks (
                        id, 
                        mode_id, 
                        unique_id, 
                        user_id, 
                        task_id, 
                        start_task_afterwards, 
                        project_id, 
                        checkpoint_id, 
                        skill_id, 
                        client_unique_id, 
                        created, 
                        data_changed
                    ) VALUES (
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s, 
                    %s, 
                    %s, 
                    %s, 
                    %s,
                    %s)
                    ''', (
                    record['id'],
                    record["mode_id"],
                    record["unique_id"],
                    record["user_id"],
                    record["task_id"],
                    record["start_task_afterwards"],
                    record["project_id"],
                    record["checkpoint_id"],
                    record["skill_id"],
                    record["client_unique_id"],
                    record["created"],
                    record["data_changed"]
                ))
                count_nfc += 1
                self.conn.commit()

            except Exception as e:
                self.conn.rollback()
                print(f"Transaction rolled back due to error: {e}")
                continue
        return f"Stored {count_nfc} / {len(json_data)} in the DWH"

    def insert_into_review_table(self, json_data: tuple) -> int:
        count_review = 0
        for record in json_data:
            try:
                # Check if the cod_channel is 'AIRBNB' and adjust review ratings accordingly
                multiplier = 2 if record['cod_channel'] == 'AIRBNB' else 1

                # Function to safely multiply rating values, returning None if the value is None
                def safe_multiply(value):
                    return value * multiplier if value is not None else None

                # Adjust ratings using the safe_multiply function
                adjusted_rating = safe_multiply(record.get('rating'))
                adjusted_rating_clean = safe_multiply(record.get('rating_clean'))
                adjusted_rating_comfort = safe_multiply(record.get('rating_comfort'))
                adjusted_rating_facilities = safe_multiply(record.get('rating_facilities'))
                adjusted_rating_location = safe_multiply(record.get('rating_location'))
                adjusted_rating_staff = safe_multiply(record.get('rating_staff'))
                adjusted_rating_value = safe_multiply(record.get('rating_value'))
                adjusted_rating_respect_house_rules = safe_multiply(record.get('rating_respect_house_rules'))
                adjusted_rating_communication = safe_multiply(record.get('rating_communication'))
                adjusted_rating_checkin = safe_multiply(record.get('rating_checkin'))

                self.cursor.execute('''
                    INSERT INTO extr_kross_reviews (
                        id_review, 
                        id_room_type, 
                        date, 
                        cod_channel, 
                        external_review_reference, 
                        external_listing_reference, 
                        external_reservation_reference, 
                        id_reservation, 
                        name_room_type, 
                        review_title, 
                        review_text, 
                        rating, 
                        rating_clean, 
                        rating_comfort, 
                        rating_facilities, 
                        rating_location, 
                        rating_staff, 
                        rating_value, 
                        rating_respect_house_rules, 
                        rating_communication, 
                        rating_checkin
                    ) VALUES (
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                         %s
                    )
                ''', (
                    record['id_review'],
                    record['id_room_type'],
                    record['date'],
                    record['cod_channel'],
                    record['external_review_reference'],
                    record['external_listing_reference'],
                    record['external_reservation_reference'],
                    record['id_reservation'],
                    record['name_room_type'],
                    record['review_title'],
                    record['review_text'],
                    adjusted_rating,
                    adjusted_rating_clean,
                    adjusted_rating_comfort,
                    adjusted_rating_facilities,
                    adjusted_rating_location,
                    adjusted_rating_staff,
                    adjusted_rating_value,
                    adjusted_rating_respect_house_rules,
                    adjusted_rating_communication,
                    adjusted_rating_checkin
                ))
                count_review += 1
                self.conn.commit()

            except Exception as e:
                self.conn.rollback()
                print(f"Transaction rolled back due to error: {e}")
                continue

        return f"Stored {count_review} / {len(json_data)} in the DWH"



    def run_fetch_data_handler(self,delta=False,since_delta = None):
        if delta and since_delta is not None:
            timetac_collector = Handler_TimeTac_API(start_time=since_delta)
            kross_collector = Handler_Kross_API(start_time=since_delta)
            print("krossi crossed")

        elif delta and since_delta is None:
            raise Exception("Delta Load needs start date as parameter! ")

        else:
            timetac_collector = Handler_TimeTac_API(start_time="2000-01-01 00:00:00")
            kross_collector = Handler_Kross_API(start_time="0001-01-01")
        try:
    # ======== FETCH TASKS ========

            print("-- Starting to fetch all tracked tasks-- ")
            tasks = timetac_collector.get_tracked_tasks()
            print(f"Fetched {len(tasks)} tasks successfully")
            print(self.insert_into_tasks_table(tasks))

    # ======== FETCH USERS ========
            print("-- Starting to fetch all tracked users-- ")
            users = timetac_collector.get_tracked_users()
            print(f"Fetched {len(users)} users successfully")
            print(self.insert_into_users_table(users))

    # ======== FETCH TIME ENTRIES ========
            print("-- Starting to fetch all tracked time entries-- ")
            time_entires = timetac_collector.get_tracked_time()
            print(f"Fetched {len(time_entires)} times successfully")
            print(self.insert_into_time_table(time_entires))

    # ======== FETCH NFC_TRACKINGS ========
            print("-- Starting to fetch all tracked nfc entries-- ")
            nfc_data = timetac_collector.get_tracked_nfc_checks()
            print(f"Fetched {len(nfc_data)} NFC trackings successfully")
            print(self.insert_into_nfc_table(nfc_data))

    # ======== FETCH REVIEWS ========
            print("-- Starting to fetch all tracked reviews-- ")
            review_data = kross_collector.get_tracked_reviews()
            print(f"Fetched {len(review_data)} reviews successfully")
            print(self.insert_into_review_table(review_data))
         

        except Exception as e:
            raise e
