import requests
from credentials import TIMETAC_API_KEY_PROD,TIMETAC_CLIENT_ID_PROD,TIMETAC_BASE_URL_PROD
import json
from datetime import datetime

def _get_access_token() -> str:
    endpoint = f'{TIMETAC_BASE_URL_PROD}/auth/oauth2/token'

    headers = {
        "Cache-Control": "no-cache",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {
        "grant_type": 'client_credentials',
        "client_id": TIMETAC_CLIENT_ID_PROD,
        "client_secret": TIMETAC_API_KEY_PROD
    }

    response = requests.post(endpoint, headers=headers, data=data)

    if response.status_code == 200:
        return response.json()
    else:
        return {
            'error': f'Failed to retrieve access token: {response.status_code}',
            'message': "test" + response.text
        }


class Handler_TimeTac_API:
    def __init__(self,start_time):
        token_json = _get_access_token()
        self.access_token = token_json['access_token']
        self.start_time = start_time

    def get_tracked_users(self) -> json:
            url = f'{TIMETAC_BASE_URL_PROD}/V3/users/read/'
            headers = {
                "accept": "application/json",
                "Authorization": f"Bearer {self.access_token}"
            }
            params = {
                # "_limit": 100,
                "_offset": 0,
                "_since": self.start_time,
                "_sort_direction": "DESC"
            }

            all_entries = []
            while True:
                response = requests.get(url, headers=headers, params=params)
                response_data = response.json()

                if 'Results' in response_data:
                    entries = response_data['Results']
                    all_entries.extend(entries)

                    # If we received fewer entries than the limit, we are done
                    if len(entries) < 100:
                        break

                    # Otherwise, increment the offset for the next request
                    params['_offset'] += 100
                else:
                    break
            return all_entries


    def get_tracked_time(self) -> json:
        url = f'{TIMETAC_BASE_URL_PROD}/V4/timeTrackings/read/'
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {self.access_token}"
        }

        params = {
            # "_limit": 100,
            "_offset": 0,
            "_since": self.start_time,
            "_sort_direction": "DESC"
        }


        all_entries = []
        while True:
            response = requests.get(url, headers=headers, params=params)
            response_data = response.json()

            if 'Results' in response_data:
                entries = response_data['Results']
                all_entries.extend(entries)

                # If we received fewer entries than the limit, we are done
                if len(entries) < 100:
                    break

                # Otherwise, increment the offset for the next request
                params['_offset'] += 100
            else:
                break
        return all_entries


    def get_tracked_tasks(self) -> json:
        url = f'{TIMETAC_BASE_URL_PROD}/V4/tasks/read/'
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {self.access_token}",
        }
        params = {
            #"_limit": 100,
            "_offset": 0,
            "_since": self.start_time,
            "_sort_direction": "DESC"
        }

        all_entries = []
        while True:
            response = requests.get(url, headers=headers, params=params)
            response_data = response.json()

            if 'Results' in response_data:
                entries = response_data['Results']
                all_entries.extend(entries)

                # If we received fewer entries than the limit, we are done
                if len(entries) < 100:
                    break

                # Otherwise, increment the offset for the next request
                params['_offset'] += 100
            else:
                break

        return all_entries


    def get_tracked_nfc_checks(self):

        url = f'{TIMETAC_BASE_URL_PROD}/V4/nfcTransponders/read/'

        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {self.access_token}"
        }
        params = {
            # "_limit": 100,
            "_offset": 0,
            "_since": self.start_time,
            "_sort_direction": "DESC"
        }

        all_entries = []

        while True:
            response = requests.get(url, headers=headers, params=params)
            response_data = response.json()

            if 'Results' in response_data:
                entries = response_data['Results']
                all_entries.extend(entries)

                # If we received fewer entries than the limit, we are done
                if len(entries) < 100:
                    break

                # Otherwise, increment the offset for the next request
                params['_offset'] += 100
            else:
                break

        return all_entries
