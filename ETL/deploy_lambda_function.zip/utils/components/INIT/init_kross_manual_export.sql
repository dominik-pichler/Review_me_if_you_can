-- noinspection SqlNoDataSourceInspectionForFile

DROP TABLE IF EXISTS KROSS_MANUAL_EXPORT;


CREATE TABLE IF NOT EXISTS KROSS_MANUAL_EXPORT (
    Guests VARCHAR(255),
    Channel VARCHAR(50),
    Date DATE,
    IdRoomType INT,
    Apt VARCHAR(255),
    Title VARCHAR(255),
    Rating DECIMAL(10, 2),
    CleaningRating DECIMAL(10, 2),
    ComfortRating DECIMAL(10, 2),
    FacilitiesRating DECIMAL(10, 2),
    LocationRating DECIMAL(10, 2),
    StaffRating DECIMAL(10, 2),
    CommunicationRating DECIMAL(10, 2),
    CheckInRating DECIMAL(10, 2),
    AccuracyRating DECIMAL(10, 2),
    ValueRating DECIMAL(10, 2),
    ReviewText TEXT,
    Author VARCHAR(255),
    Country VARCHAR(100),
    ReservationCode VARCHAR(50),
    Reservation VARCHAR(255),
    Arrival DATE,
    Departure DATE,
    Nights DECIMAL(10, 2),
    Reply TEXT,
    OnBE BOOLEAN
);