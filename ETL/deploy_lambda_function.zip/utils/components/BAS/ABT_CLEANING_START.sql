DROP TABLE IF EXISTS ABT_CLEANING_START;
CREATE TABLE ABT_CLEANING_START AS
SELECT
    fullname,
    DATE(start_time) AS date,
    MIN(start_time::time) AS first_start
FROM
    extr_timetac_time_entries t
LEFT JOIN
    extr_timetac_users u ON t.user_id = u.id
GROUP BY
    fullname,
    DATE(start_time)
ORDER BY
    fullname,
    date;