DROP TABLE IF EXISTS ABT_CLEANING_END_GROUPS;

CREATE TABLE IF NOT EXISTS ABT_CLEANING_START_GROUPS AS
SELECT *,
       CASE
           WHEN last_end_time > '17:30:00' OR first_start <  '09:30:00' THEN 'Red Group'
           WHEN last_end_time >= '16:00:00' AND last_end_time <= '17:30:00' AND first_start >= '09:30:00' AND first_start < '11:00:00'  THEN 'Yellow Group'
       ELSE
       'Green Group'
       END AS Cleaning_Group
FROM ABT_CLEANING_TIME_ANALYSIS;



